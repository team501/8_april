/**
 * Language Provider Helper Component
 * Used to Display Localised Strings
 */
import React from 'react';
import { FormattedMessage, injectIntl } from 'react-intl';

// Injected message
const InjectMassage = props => <FormattedMessage tagName="tspan" {...props} />;

export default injectIntl(InjectMassage, {
    withRef: false
});
