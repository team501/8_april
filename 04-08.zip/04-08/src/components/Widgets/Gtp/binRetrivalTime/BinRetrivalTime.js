import React, { Component } from 'react';

//import './landing.css';

class OverallWorkMonitor extends Component {
    render(){
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="componentbg overall-work-monitor">
							<div className="title">Bin Retrival Time</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
